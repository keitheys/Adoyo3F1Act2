const express = require('express');
const router = express.Router();
const page = require('../controller/Hpcontroller');

router.get('/', page.index);

module.exports = router;